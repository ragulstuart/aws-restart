myFruitList = ["apple", "banana", "cherry"]
#rint(myFruitList)
#rint(type(myFruitList))
#print(myFruitList[0])
#print(myFruitList[1])
#print(myFruitList[2])

myFruitList[2] = "orange"
#print(myFruitList)
myFinalAnswerTuple = ("apple", "banana", "pineapple")
#rint(myFinalAnswerTuple)
#rint(type(myFinalAnswerTuple))
#rint(myFinalAnswerTuple[0])
#rint(myFinalAnswerTuple[1])
#rint(myFinalAnswerTuple[2])

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(myFavoriteFruitDictionary["Akua"])

print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])